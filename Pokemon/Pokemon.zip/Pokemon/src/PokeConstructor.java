
public interface PokeConstructor {
	static void createPokemon(String name, String type, int health) {
	}
	static void attackPokemon(Pokemon pokemon) {
		
	}
	static void pokemonInfo(Pokemon pokemon) {
		
	}
}
