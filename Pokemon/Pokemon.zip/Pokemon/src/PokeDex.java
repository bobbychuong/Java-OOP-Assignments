
public abstract class PokeDex extends PokeLab{
	public void pokemonInfo(Pokemon pokemon) {
		
	}
}
