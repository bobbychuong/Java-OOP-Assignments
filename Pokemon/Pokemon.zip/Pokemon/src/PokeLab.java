
public abstract class PokeLab implements PokeConstructor{
	public void createPokemon() {
		System.out.println("Creating Pokemon");
	}
	public void attackPokemon() {
		System.out.println("Attacking Pokemon");
	}
}
