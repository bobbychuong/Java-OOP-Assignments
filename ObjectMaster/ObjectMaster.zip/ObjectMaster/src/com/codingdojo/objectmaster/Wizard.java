package com.codingdojo.objectmaster;

public class Wizard extends Human {

}
