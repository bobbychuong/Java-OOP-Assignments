package com.codingdojo.zookeeper;

public class GorillaTest {

	public static void main(String[] args) {
		Gorilla g = new Gorilla();
		g.throwing();
		g.throwing();
		g.throwing();
		g.eatBananas();
		g.eatBananas();
		g.climb();
		g.displayHealth();
	}

}
