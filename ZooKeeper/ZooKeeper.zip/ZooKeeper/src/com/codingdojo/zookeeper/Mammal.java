package com.codingdojo.zookeeper;

public class Mammal {
	protected int energyLevel = 100;
	public void displayHealth() {
		System.out.print("Animal's energy level:" + energyLevel);
	}
}
